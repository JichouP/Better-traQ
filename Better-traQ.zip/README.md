# Better-traQ

[![CodeQL](https://github.com/JichouP/Better-traQ/actions/workflows/codeql-analysis.yml/badge.svg)](https://github.com/JichouP/Better-traQ/actions/workflows/codeql-analysis.yml)

An Extension that Makes traQ Useful

![screenshot](https://raw.githubusercontent.com/JichouP/Better-traQ/master/screenshot/screenshot.png)

## Build (Firefox)

```bash
# Install Dependencies
pnpm install

# Build
pnpm build:traQ:firefox # for Better traQ
# or
pnpm build:ex-traQ:firefox # for Better ex-traQ
```
