type Page = 'home' | 'docs' | 'setting' | 'changelog';
