type Task = {
  name: string;
  keybinds: Keybind[];
  actions: import('@/store/zAction').ActionEnum[];
};
