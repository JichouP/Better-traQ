import eUnreadCh from './eUnreadCh';

const neUnreadCh = (): boolean => !eUnreadCh();

export default neUnreadCh;
