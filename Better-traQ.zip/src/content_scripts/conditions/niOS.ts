import iOS from './iOS';

const niOS = (): boolean => !iOS();

export default niOS;
