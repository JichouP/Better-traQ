import iFNUUserFilterInput from './iFNUUserFilterInput';

const niFNUUserFilterInput = (): boolean => !iFNUUserFilterInput();

export default niFNUUserFilterInput;
