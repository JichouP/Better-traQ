import iFInputOrTextarea from './iFInputOrTextarea';

const niFInputOrTextarea = (): boolean => !iFInputOrTextarea();

export default niFInputOrTextarea;
