import iFNCChFilterInput from './iFNCChFilterInput';

const niFNCChFilterInput = (): boolean => !iFNCChFilterInput();

export default niFNCChFilterInput;
