import eHomeCh from './eHomeCh';

const neHomeCh = (): boolean => !eHomeCh();

export default neHomeCh;
