declare module '@/../CHANGELOG.md' {
  const changelog: string;
  export default changelog;
}
