/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
module.exports = {
  plugins: [require('tailwindcss'), require('autoprefixer')],
};
